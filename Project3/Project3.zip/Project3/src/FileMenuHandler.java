import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

/**
 * The FileMenuHandler class handles action events for the file menu items.
 * It provides methods to open a file using a file chooser dialog and read/display its contents.
 */
// This class handles the action events for the file menu items
public class FileMenuHandler implements ActionListener {
    JFrame jframe; // JFrame reference
    /**
     * Constructs a FileMenuHandler object with a reference to the JFrame.
     *
     * @param jf The JFrame to associate with this FileMenuHandler.
     */
    // Constructor to initialize the JFrame reference
    public FileMenuHandler (JFrame jf) {
        jframe = jf;
    }
    // This method is invoked when an action event occurs
    /**
     * Invoked when an action event occurs.
     *
     * @param event The ActionEvent object generated when a menu item is clicked.
     */
    public void actionPerformed(ActionEvent event) {
        String menuName;
        menuName = event.getActionCommand();
        // Check which menu item was clicked
        if (menuName.equals("Open"))
            openFile( );
        else if (menuName.equals("Quit"))
            // If Quit is clicked, exit the program
            System.exit(0);
    } //actionPerformed

    /**
     * Opens a file using a file chooser dialog.
     */
    // Method to open a file using a file chooser dialog
    private void openFile( ) {
        JFileChooser chooser;
        int status;
        chooser = new JFileChooser( );
        // Display the file chooser dialog and get the user's selection
        status = chooser.showOpenDialog(null);
        // If the user selects a file, read its contents
        if (status == JFileChooser.APPROVE_OPTION)
            readSource(new File(chooser.getSelectedFile().getAbsolutePath()));
        else
            JOptionPane.showMessageDialog(null, "Open File dialog canceled");
    } //openFile

    /**
     * Reads and displays the contents of the selected file.
     *
     * @param chosenFile The File object representing the selected file.
     */
    // Method to read and display the contents of the selected file
    private void readSource(File chosenFile) {
        String chosenFileName = chosenFile.getName();
        TextFileInput inFile = new TextFileInput(chosenFileName); // TextFileInput is assumed to be a custom class for reading files
        String marston;
        int subscript = 0;
        Container myContentPane = jframe.getContentPane(); // Get the content pane of the JFrame
        TextArea myTextArea = new TextArea(); // Create a TextArea to display the file contents
        TextArea mySubscripts = new TextArea(); // Create a TextArea to display line numbers
        // Add the TextAreas to the content pane
        myContentPane.add(myTextArea, BorderLayout.EAST); // Add myTextArea to the right side of the JFrame
        myContentPane.add(mySubscripts, BorderLayout.WEST); // Add mySubscripts to the left side of the JFrame

        // Read each line from the file and display it in the TextAreas
        marston = inFile.readLine();
        while (marston != null) {
            mySubscripts.append(Integer.toString(subscript++)+"\n"); // Display line numbers
            myTextArea.append(marston+"\n"); // Display file contents
            marston = inFile.readLine();
        }
        jframe.setVisible(true); // Make the JFrame visible after adding components
    }
}